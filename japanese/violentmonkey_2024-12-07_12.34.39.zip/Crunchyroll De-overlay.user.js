// ==UserScript==
// @name        Crunchyroll De-overlay
// @namespace   Violentmonkey Scripts
// @match       https://static.vrv.co/vilos/player.html*
// @match       https://static.crunchyroll.com/vilos-v2/web/vilos/player.html*
// @grant       none
// @version     1.0
// @author      -
// @description 4/28/2023, 9:03:48 PM
// ==/UserScript==
let s = document.createElement('style');
s.type = 'text/css';
s.appendChild(document.createTextNode(`
.css-1dbjc4n.r-1pi2tsx.r-1d2f490.r-6dt33c.r-u8s1d.r-ipm5af.r-13qz1uu {
  background: none !important;
}
`));

document.getElementsByTagName('head')[0].appendChild(s);