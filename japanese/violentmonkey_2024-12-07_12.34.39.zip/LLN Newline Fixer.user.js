// ==UserScript==
// @name        LLN Newline Fixer
// @match       https://www.netflix.com/*
// @grant       none
// @version     1.0
// @author      voithos
// @description Fixes newlines in LLN so that they work with Yomichan
// ==/UserScript==

setInterval(() => {
  const newlines = document.querySelectorAll('.lln-newline');
  for (let nl of newlines) {
    nl.textContent = ' ';
  }
}, 500);