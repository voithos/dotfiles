// ==UserScript==
// @name         Wanikani Reibun Answer Spoiler
// @namespace    mailto:benedictide@gmail.com
// @version      0.1
// @description  Blurs the English translations of context sentences white so they can't be seen unless hovered over or highlighted.
// @author       Benedict Ide
// @match        https://www.wanikani.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    let css = '.context-sentences>p:nth-child(2), #section-context p:nth-child(2) {color: transparent;text-shadow: 0 0 9px rgba(0,0,0,0.5);padding: 2px !important;padding-left:10px !important}.context-sentences>p:nth-child(2):hover, #section-context p:nth-child(2):hover {color: black;text-shadow: none;}';
    let style = document.createElement('style');

    if (style.styleSheet) {
        style.styleSheet.cssText = css;
    } else {
        style.appendChild(document.createTextNode(css));
    }
    document.getElementsByTagName('head')[0].appendChild(style);
})();