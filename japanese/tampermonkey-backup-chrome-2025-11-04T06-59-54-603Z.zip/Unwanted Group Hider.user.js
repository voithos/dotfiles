// ==UserScript==
// @name        Unwanted Group Hider
// @namespace   Violentmonkey Scripts
// @match       https://mail.google.com/mail/u/0/*
// @match       https://chat.google.com/u/0/*
// @grant       none
// @version     1.0
// @author      -
// @description 5/14/2024, 12:23:10 AM
// ==/UserScript==

const searchText = [
  'PokeDECZ',
  'Serious Business Only',
  'Lightbox 2023',
  'Pantheon Alums Happy Hour',
  'Exercise Time!',
  'SIGGRAPH 2018',

  'Sam, Connie',
  'Connie, Levi',
  'Connie, Edward',
  'Connie, Daisy',
];

const intervalID = setInterval(() => {
  let spans = document.querySelectorAll('span[role=listitem]');
  for (let span of spans) {
    const match = searchText.some((text) => span.innerText.toUpperCase().includes(text.toUpperCase()));
    if (match) {
      span.remove();
    }
  }
}, 500);